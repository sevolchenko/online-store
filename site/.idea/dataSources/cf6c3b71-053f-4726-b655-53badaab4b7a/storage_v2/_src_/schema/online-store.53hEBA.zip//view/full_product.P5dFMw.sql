create definer = admin@`%` view full_product as
select `online-store`.`product`.`product_id`          AS `product_id`,
       `online-store`.`product`.`name`                AS `product_name`,
       `online-store`.`product`.`description`         AS `description`,
       `online-store`.`category`.`name`               AS `category_name`,
       `online-store`.`product`.`color`               AS `color`,
       `online-store`.`product`.`materials`           AS `materials`,
       `online-store`.`product`.`initial_price`       AS `initial_price`,
       `online-store`.`product`.`current_price`       AS `current_price`,
       `online-store`.`product`.`release_date`        AS `release_date`,
       `online-store`.`product`.`state_of_shown_info` AS `state_of_shown_info`,
       `online-store`.`photo`.`position`              AS `photo_position`,
       `online-store`.`photo`.`product_photo`         AS `product_photo`
from ((`online-store`.`product` join `online-store`.`category` on ((`online-store`.`product`.`category_id` =
                                                                    `online-store`.`category`.`category_id`)))
         left join `online-store`.`photo`
                   on ((`online-store`.`product`.`product_id` = `online-store`.`photo`.`product_id`)));

